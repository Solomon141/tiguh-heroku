const SendConfirmationMail = require('./Collection/MailSender')
const toEmail = 'weymit2001@gmail.com'
SendConfirmationMail(toEmail)